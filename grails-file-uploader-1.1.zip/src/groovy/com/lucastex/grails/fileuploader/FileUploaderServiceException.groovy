package com.lucastex.grails.fileuploader

class FileUploaderServiceException extends Exception {

  FileUploaderServiceException(String msg) {
    super(msg)
  }
}
